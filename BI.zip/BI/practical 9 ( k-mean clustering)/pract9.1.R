# Load necessary library
library(ggplot2)

# Given dataset
data <- matrix(c(1,2, 1,4, 1,0, 10,2, 10,4, 10,0), ncol=2, byrow=TRUE)

# Perform K-means clustering
set.seed(0)
kmean_result <- kmeans(data, centers = 2)

# Convert data to dataframe
data_df <- data.frame(x = data[,1], y = data[,2], cluster = as.factor(kmean_result$cluster))

# Convert cluster centers to dataframe
centers_df <- data.frame(x = kmean_result$centers[,1], y = kmean_result$centers[,2])

# Plot clusters
ggplot(data_df, aes(x = x, y = y, color = cluster)) +
  geom_point(size = 3) +
  geom_point(data = centers_df, aes(x = x, y = y), color = 'red', size = 5, shape = 4) +
  ggtitle("K-Means Clustering")

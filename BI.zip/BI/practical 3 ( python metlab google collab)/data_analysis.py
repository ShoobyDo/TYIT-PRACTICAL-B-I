import matplotlib
matplotlib.use('TkAgg') 

import pandas as pd
import matplotlib.pyplot as plt


# Load the CSV file (Ensure 'sample.csv' is in the same directory)
csv_file = "sample.csv"

try:
    # Read the CSV file using pandas
    df = pd.read_csv(csv_file)
    print("Initial Data Preview:")
    print(df.head())  # Display the first 5 rows

    # Check basic statistics
    print("\nDataset Summary:")
    print(df.describe())

    # Plot a visualization (Example: First numeric column)
    df.iloc[:, 1].hist(bins=20, edgecolor='black')
    plt.title("Histogram of Column 1")
    plt.xlabel("Value")
    plt.ylabel("Frequency")
    plt.show()

except FileNotFoundError:
    print(f"Error: {csv_file} not found. Make sure the file exists in the directory.")
except Exception as e:
    print(f"An error occurred: {e}")

library(forecast)
library(tseries)

# part 1
data<-AirPassengers

ts_data<-ts(data,start=c(1949,1),frequency = 12)
print(ts_data)

plot(ts_data,main="Monthly Air passangers(1949-1960)",xlab="year",ylab="passangers",col="blue",lwd=2)

decomposed_data<-decompose(ts_data)
plot(decomposed_data)

# part2
delf_test<-adf.test(ts_data)
print(delf_test)

diff_ts_data<-diff(ts_data,differences=1)
plot(diff_ts_data,main="Differenced time series",col='red',lwd=2)

#part3
fit<-auto.arima(ts_data)
summary(fit)

forcast_values<-forecast(fit,h=12)
plot(forcast_values,main="forecast for next 12 months",col='blue',lwd=2)
# Creating a small dataset similar to the iris dataset
mydata <- data.frame(
  Sepal.Length = c(5.1, 4.9, 6.2, 7.0, 5.8, 6.5, 5.0, 6.3, 7.1, 5.4),
  Sepal.Width  = c(3.5, 3.0, 3.4, 3.2, 2.7, 2.8, 3.6, 2.9, 3.0, 3.9),
  Petal.Length = c(1.4, 1.4, 5.4, 4.7, 4.1, 5.2, 1.5, 4.9, 6.1, 1.3),
  Petal.Width  = c(0.2, 0.2, 2.3, 1.4, 1.3, 2.0, 0.3, 1.8, 2.5, 0.4),
  Species      = c("Setosa", "Setosa", "Virginica", "Versicolor", "Versicolor",
                   "Virginica", "Setosa", "Versicolor", "Virginica", "Setosa")
)

# Display dataset
print(mydata)

# Save the dataset as CSV (for practice)
write.csv(mydata, "mydata.csv", row.names = FALSE)

# Load the dataset
mydata <- read.csv("mydata.csv")

# View first few rows
head(mydata)


# Remove Species column for clustering
newdata <- mydata
newdata$Species <- NULL

# Compute Euclidean distance
dist_matrix <- dist(newdata, method = "euclidean")

# Perform hierarchical clustering
hc <- hclust(dist_matrix, method = "ward.D")

# Plot dendrogram
plot(hc, main = "Hierarchical Clustering Dendrogram", sub = "", xlab = "")

# Cut the tree into 3 clusters
clusters <- cutree(hc, k = 3)

# Compare clusters with actual species
table(mydata$Species, clusters)

# Visualize clusters using ggplot
library(ggplot2)
ggplot(newdata, aes(x = Sepal.Length, y = Sepal.Width, color = as.factor(clusters))) +
  geom_point(size = 3) +
  labs(title = "Hierarchical Clustering", color = "Cluster")



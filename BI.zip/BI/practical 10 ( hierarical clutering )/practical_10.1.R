# Remove the species column from the dataset
newiris <- iris
newiris$Species <- NULL  # Remove the 'Species' column

# Perform k-means clustering with 3 clusters
Kc <- kmeans(newiris, 3)

# Create a table to compare the actual species with the clusters
table(iris$Species, Kc$cluster)

# Plot the clusters based on Sepal.Length and Sepal.Width
plot(newiris[c("Sepal.Length", "Sepal.Width")], col=Kc$cluster, pch=8, cex=2)